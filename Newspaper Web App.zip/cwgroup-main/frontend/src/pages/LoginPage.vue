<template>
    <div>
      <h1>Login</h1>
      <form @submit.prevent="loginUser">
        <input type="text" v-model="username" placeholder="Username" />
        <input type="password" v-model="password" placeholder="Password" />
        <button type="submit">Login</button>
        <p v-if="errorMessage">{{ errorMessage }}</p>
      </form>
    </div>
  </template>
  
  <script lang="ts">
  export default {
    data() {
      return {
        username: '',
        password: '',
        errorMessage: ''
      };
    },
    methods: {
      loginUser() {
        fetch('http://localhost:8000/login/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            username: this.username,
            password: this.password
          })
        })
        .then(response => {
          if (response.ok) {
            return response.json();
          } else {
            return response.json().then(err => {
              throw new Error(err.message || 'Failed to log in');
            });
          }
        })
        .then(data => {
          console.log(data); // Handle the response
          // Redirect or update state after successful login
          // e.g., this.$router.push('/dashboard');
        })
        .catch(error => {
          // Handle specific or general errors
          this.errorMessage = error.message || 'Login failed. Please check your credentials.';
        });
      }
    }
  };
  </script>
  
  <!-- Add styles as needed -->
  
