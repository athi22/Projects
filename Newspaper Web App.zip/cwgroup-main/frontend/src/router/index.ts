// Example of how to use Vue Router

import { createRouter, createWebHistory } from 'vue-router';

// 1. Define route components.
// These can be imported from other files
import MainPage from '../pages/MainPage.vue';
import OtherPage from '../pages/OtherPage.vue';
import LoginPage from '../pages/LoginPage.vue'; // Ensure correct relative path

// Determine the base URL for the router
let base = (import.meta.env.MODE === 'development') ? import.meta.env.BASE_URL : '';

// 2. Define some routes
// Each route should map to a component.
const router = createRouter({
    history: createWebHistory(base),
    routes: [
        { path: '/', name: 'Main Page', component: MainPage },
        { path: '/other', name: 'Other Page', component: OtherPage },
        { path: '/login', name: 'Login', component: LoginPage },
    ]
});

export default router;
