README - Fall Detection System Project

Dataset Usage Instructions

Using Provided Dataset
If you choose to use the CompleteDataset.csv file provided with this project:

No modifications needed: You do not need to rename any column headers as they are already formatted correctly for use with the project scripts.

Using Dataset from Official Website
If you download the dataset from the official website, you will need to make some adjustments to the column headers:

Rename Column Headers: Open the CompleteCode.csv file included in this project. Copy the entire row of renamed column headers.
Replace Headers: Paste these headers into the first row of the dataset you downloaded, replacing the original headers. This step ensures compatibility with the project code.

Alternatively copy and paste this: TimeStamps,AnkleAccelerometer x-axis (g),AnkleAccelerometer y-axis (g),AnkleAccelerometer z-axis (g),AnkleAngularVelocity x-axis (deg/s),AnkleAngularVelocity y-axis (deg/s),AnkleAngularVelocity z-axis (deg/s),AnkleLuminosity illuminance (lx),RightPocketAccelerometer x-axis (g),RightPocketAccelerometer y-axis (g),RightPocketAccelerometer z-axis (g),RightPocketAngularVelocity x-axis (deg/s),RightPocketAngularVelocity y-axis (deg/s),RightPocketAngularVelocity z-axis (deg/s),RightPocketLuminosity illuminance (lx),BeltAccelerometer x-axis (g),BeltAccelerometer y-axis (g),BeltAccelerometer z-axis (g),BeltAngularVelocity x-axis (deg/s),BeltAngularVelocity y-axis (deg/s),BeltAngularVelocity z-axis (deg/s),BeltLuminosity illuminance (lx),NeckAccelerometer x-axis (g),NeckAccelerometer y-axis (g),NeckAccelerometer z-axis (g),NeckAngularVelocity x-axis (deg/s),NeckAngularVelocity y-axis (deg/s),NeckAngularVelocity z-axis (deg/s),NeckLuminosity illuminance (lx),WristAccelerometer x-axis (g),WristAccelerometer y-axis (g),WristAccelerometer z-axis (g),WristAngularVelocity x-axis (deg/s),WristAngularVelocity y-axis (deg/s),WristAngularVelocity z-axis (deg/s),WristLuminosity illuminance (lx),BrainSensor,Infrared1,Infrared2,Infrared3,Infrared4,Infrared5,Infrared6,Subject,Activity,Trial,Tag

Preparing Train and Test Datasets
To generate the train and test datasets necessary for running the machine learning models:

Run the Code: Execute the provided scripts up to the section labeled "Train and test datasets prepared and saved".
This will process the data and split it into training and testing sets, saving them as separate CSV files (train.csv and test.csv).


Additional Information

Ensure you have all the necessary libraries and dependencies installed as outlined in the requirements.txt file.
Follow the code execution steps in the order presented to avoid any issues with file dependencies or missing data.
